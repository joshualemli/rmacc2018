

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    Using the `fetch` API
    Joshua A. Lemli
    2018


    four test functions:
    --------------------
    test1 - barebones `fetch` usage
    test2 - formatting a CSV text string
    test3 - old style requests (IE)
    test4 - json formatting


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */


"use strict";


// URL to fetch
const csvUrl = "https://raw.githubusercontent.com/joshualemli/rmacc2018/master/sitesSpatialInfo.csv"
const jsonUrl = "https://raw.githubusercontent.com/joshualemli/rmacc2018/master/spoofObject.json"


// read the data as text, output unformatted text
const test1 = () => {
    // run the fetch function
    fetch(csvUrl)
    // resolves to a response object
    .then( response => response.text() )
    // resolves to the parsed result
    .then( result => {
        document.getElementById("output").innerHTML = result
    })
}


// read the data as text, re-format the data as a 2-D array, output as HTML table
const test2 = () => {
    // regular Expression for finding newlines or carriage returns
    const regExpForRows = /[\n\r]+/g
    // regular Expression for finding tabs or commas
    const regExpForCols = /[\t,]/g
    // fetch the data
    fetch(csvUrl).then( r => r.text() ).then( data => {
        // parse the data
        let cellData = data.split(regExpForRows).map(row => row.split(regExpForCols))
        // create a table
        var table = document.createElement("table")
        document.getElementById("output").appendChild(table)
        // add rows
        cellData.forEach( (row,rowIndex) => {
            var tr = document.createElement("tr")
            // add columns
            row.forEach( column => {
                var td = document.createElement( rowIndex ? "td" : "th")
                td.innerHTML = column
                tr.appendChild(td)
            })
            table.appendChild(tr)
        })
    })
}


// Old style (XML-HTTP-Request)
const test3 = () => {
    // create the request object
    var xhr = new XMLHttpRequest()
    // set the error callback
    xhr.onerror = function(error) {
        throw new Error(error)
    }
    // set the ready-state change callback
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById("output").innerHTML = "XHR still works great!<hr>" + xhr.response
        }
    }
    // start the request
    xhr.open("GET",csvUrl)
    xhr.send()
}


// fetch a file and parse the response as JSON
const test4 = () => {
    fetch(jsonUrl).then( r => r.json() ).then( r => console.log(r) )
}


