
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    Plotly Demo
    Joshua A. Lemli
    2018

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */


"use strict";

const Demo = (function(){

    // static constant
    const DATA_API_URL = "https://DataCorral.uwyo.edu/RemoteDb/"

    // dom pointers
    var yearElement, monthElement

    // plot the data for a specified site
    const plotSiteData = () => {
        // get the date
        let year = yearElement.value
        let month = monthElement.value
        var startDate = year + "/" + month + "/01"
        var endDate = month == 12 ? `${parseInt(year)+1}/01/01` : `${year}/${parseInt(month)+1}/1`
        // query the remote API
        fetch(DATA_API_URL + "QueryTable",{
            method: "post",
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify({
                Token: "k6XlXk741Nh4VrTpRrNVsdre5qVnXrEt5QhLyS7i",
                Database: "WyCEHG_New",
                Table: "tblSapFlow",
                Filters: [
                    { field:"Samp_Date", Min: startDate, Max: endDate }, // date range
                    { field:"Visible", EqualTo:1 }, // this is just filtering out unpublished data
                    { field:"Flag_Indicator", EqualTo:0 }, // this is just filtering out non QA/QC'd data
                ]
            })
        // parse the response as JSON, then iterate through the results
        }).then( response => response.json() ).then( result => {
            var series = new Map()
            result.data.forEach( point => {
                var pointSiteId = point[0]
                // create series if DNE
                if (!series.has(pointSiteId)) series.set(pointSiteId,{
                    x: [],
                    y: [],
                    mode: "markers",
                    type: "scatter",
                    name: pointSiteId
                })
                // get the array
                var sitePoints = series.get(pointSiteId)
                sitePoints.x.push(point[1]) // time value
                sitePoints.y.push(point[5]) // dependent value
            })
            // load into array for Plotly function
            var seriesArr = []
            series.forEach( x => seriesArr.push(x) )
            // create plots, notify user if the dataset is empty
            if (seriesArr.length === 0) alert("The selected time interval contains no data.")
            Plotly.newPlot("plotContainer",seriesArr)
        })
    }


    // initialization function
    const init = function() {
        window.removeEventListener("load",init)
        // set pointers to dom elements
        yearElement = document.getElementById("yearSelect")
        monthElement = document.getElementById("monthSelect")
        // add event listener to input elements
        yearElement.onchange = plotSiteData
        monthElement.onchange = plotSiteData
        // plot the current (initial) selection
        plotSiteData()
    }
    // init after page load
    window.addEventListener("load",init)

})()



