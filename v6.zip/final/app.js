
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    Final Demo - Visualizing Data with JavaScript APIs
    Joshua A. Lemli
    2018

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */


"use strict";

var app // declare the module outside of the `require` scope

// use dojo `require` to import modules
require([
    "https://cdn.plot.ly/plotly-latest.min.js",
    "esri/Map",
    "esri/layers/GraphicsLayer",
    "esri/views/SceneView",
    "esri/Graphic",
    "esri/geometry/Extent",
    "dojo/ready",
    "dojo/domReady!"
],function(
    Plotly,
    esriMap,
    esriGraphicsLayer,
    esriSceneView,
    esriGraphic,
    esriExtent,
    dojoReady
){app = (function(){ // define the module inside of the `require` scope


    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    //      STATIC CONSTANTS
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    const TIME_RANGE_MIN = "2016/05/01"
    const TIME_RANGE_MAX = "2016/06/01"
    const DATA_API_URL = "https://DataCorral.uwyo.edu/RemoteDb/"
    const SITE_CSV_URL = "https://raw.githubusercontent.com/joshualemli/rmacc2018/master/sitesSpatialInfo.csv"
    const NORMAL_POINT_COLOR = [0,114,178]
    const HIGHLIGHT_POINT_COLOR = [240,228,0]


    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    //      PERSISTENT LOCALLY-SCOPED OBJECTS
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    var sceneView = null
    var graphicsLayer = null
    var highlightedSiteGraphic = null


    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    //      INITIALIZATION FUNCTION / ENTRY POINT
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    // fires when all modules have been loaded
    dojoReady( () => {
        // create the esri map
        initMap()
        // get site info from the online CSV and create the site points on the map
        getCsvDataFromUrl(SITE_CSV_URL).then( sitesInfo => {
            // build points on map
            sitesInfo.rows.forEach( site => {
                addMapPoint(site[0],site[2],site[1])
            })
            // set default extent to match points
            // --> first create an extent from the first point
            var sitesExtent = new esriExtent({
                xmin: graphicsLayer.graphics.items[0].geometry.x, ymin: graphicsLayer.graphics.items[0].geometry.y,
                xmax: graphicsLayer.graphics.items[0].geometry.x, ymax: graphicsLayer.graphics.items[0].geometry.y,
            })
            // --> loop through the sites and union the extent with each point's extent
            graphicsLayer.graphics.items.forEach( item => {
                sitesExtent = sitesExtent.union(new esriExtent({
                    xmin:item.geometry.x, ymin:item.geometry.y, xmax:item.geometry.x, ymax:item.geometry.y,
                }))
            })
            // --> expand the extent, and set the map extent
            sitesExtent = sitesExtent.expand(10)
            sceneView.extent = sitesExtent
        })
    })


    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    //      FUNCTIONAL PROGRAMMING METHODS
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    // request and parse csv data from a URL, returns a promise
    const getCsvDataFromUrl = (url) => {
        // regular Expression for finding newlines or carriage returns
        const regExpForRows = /[\n\r]+/g
        // regular Expression for finding tabs or commas
        const regExpForCols = /[\t,]/g
        // fetch the url, parse response as text, parse text as CSV
        return fetch(url).then( response => response.text() ).then( csvText => {
            // split by newline, then by column delimiter, then remove rows without data
            var data = csvText.split(regExpForRows).map(row => row.split(regExpForCols)).filter(row => row.length > 1)
            return {
                columnNames: data.splice(0,1)[0],
                rows: data
            }
        })
    }

    // create the map and add a graphics layer
    const initMap = () => {
        // create a 3-D view
        sceneView = new esriSceneView({
            container: "mapContainer",
            map: new esriMap({
                basemap: "satellite",
                ground: "world-elevation"
            }),
            scale: 5000000,
            center: [-107.5, 43]
        })
        // create a layer to contain our graphics
        graphicsLayer = new esriGraphicsLayer()
        sceneView.map.add(graphicsLayer)
        // add an event handler for map click events
        sceneView.on("click", (event) => {
            // fire a `hitTest` on the event
            sceneView.hitTest(event).then( (response) => {
                // check if there were results
                if (response.results.length) {
                    // plot data and highlight the map graphic
                    document.getElementById("currentSiteId").innerHTML = response.results[0].graphic.attributes.SiteID
                    plotSiteData(response.results[0].graphic.attributes.SiteID)
                    highlightGraphic(response.results[0].graphic)
                }
            })
        })
    }

    // returns an esri point symbol of specified color
    const siteSymbol = color => new Object({
        type: "point-3d",
        symbolLayers: [{
            type: "icon",
            size: 10,
            resource: { primitive: "circle" },
            outline: {
                color:"white",
                size:1
            },
            material: { color: color } // this is where the color parameter is used
        }],
        callout: {
            type: "line",
            size: 1.5,
            color: [128,128,128],
        },
        verticalOffset: {
            screenLength: 60,
            minWorldLength: 40,
            maxWorldLength: 5000,
        }
    })

    // add a point (representing a point) to the map
    const addMapPoint = (id,x,y) => {
        graphicsLayer.add(new esriGraphic({
            geometry: {type:"point", x:x, y:y},
            symbol: siteSymbol(NORMAL_POINT_COLOR),
            attributes: {SiteID:id}
        }))
    }

    // plot the data for a specified site
    const plotSiteData = siteId => {
        // query the remote API
        fetch(DATA_API_URL + "QueryTable",{
            method: "post",
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify({
                Token: "k6XlXk741Nh4VrTpRrNVsdre5qVnXrEt5QhLyS7i",
                Database: "WyCEHG_New",
                Table: "tblSapFlow",
                Filters: [
                    { field:"SiteID", EqualTo: siteId }, // specify the SiteID
                    { field:"Samp_Date", Min:TIME_RANGE_MIN, Max:TIME_RANGE_MAX }, // date range
                    { field:"Visible", EqualTo:1 }, // this is just filtering out unpublished data
                    { field:"Flag_Indicator", EqualTo:0 }, // this is just filtering out non QA/QC'd data
                ]
            })
        }).then( response => response.json() ).then( result => {
            console.log(`fetched ${result.data.length} data points for site id = ${siteId}`)
            // create arrays to push our x- and y-values to
            var xValues = [], yValues = []
            result.data.forEach( point => {
                xValues.push(point[1]) // time value
                yValues.push(point[5]) // dependent value
            })
            // create a single timeseries plot
            Plotly.newPlot("plotContainer",[{
                x:xValues,
                y:yValues,
                mode:'markers',
                type:'scatter'
            }])

        })
    }

    // highlight a map graphic (removes previous highlight graphic)
    const highlightGraphic = graphic => {
        // 1 - remove the previous highlighted graphic
        if (highlightedSiteGraphic) {
            graphicsLayer.remove(highlightedSiteGraphic)
            var normalGraphic = new esriGraphic({
                geometry: highlightedSiteGraphic.geometry.clone(),
                attributes: highlightedSiteGraphic.attributes,
                symbol: siteSymbol(NORMAL_POINT_COLOR)
            })
            graphicsLayer.add(normalGraphic)
        }
        // 2 - highlight current graphic
        graphicsLayer.remove(graphic)
        highlightedSiteGraphic = new esriGraphic({
            geometry: graphic.geometry.clone(),
            attributes: graphic.attributes,
            symbol: siteSymbol(HIGHLIGHT_POINT_COLOR)
        })
        graphicsLayer.add(highlightedSiteGraphic)
    }


    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    //      PUBLIC ACCESSOR
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    return {
        getView() { return sceneView }
    }

})()})
