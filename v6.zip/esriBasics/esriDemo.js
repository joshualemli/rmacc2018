
/*
    ESRI JS-API v4.x and Dojo Toolkit Demo
    Joshua A. Lemli
    2018
*/


"use strict";


// Dojo `require` is used to load modules, either from a pre-defined namespace or a URL.
// In this example, a polyfill for the JavaScript Promise object is imported and used.
require(["dojo/Deferred"],function(dojoDeferred){
    var defer = new dojoDeferred()
    setTimeout(defer.resolve,2500)
    defer.promise.then( () => console.log("spoof promise has resolved") )
})


// Create a simple map, and add a JavaScript interval to animate the map
// This `require` imports the modules needed to create a map.
require([
    "esri/Map",
    "esri/views/SceneView",
    "dojo/domReady!" // this is a special module that forces the callback to wait for the document to be loaded
],function(
    esriMap,
    esriSceneView
){

    // create a 3-D view
    var sceneView = new esriSceneView({
        container: "map",
        map: new esriMap({
            basemap: "satellite",
            ground: "world-elevation"
        }),
        scale: 1000000,
        center: [-107.5, 30]
    })

    const panStep = function(){
        let camera = sceneView.camera.clone()
        camera.position.longitude += 1
        camera.position.z *= 0.85
        camera.tilt += camera.tilt > 40 ? -5 : 5
        camera.heading += 8
        sceneView.goTo(camera,{
            animate:true,
            duration:5000,
            easing:"linear"
        })
    }

    sceneView.when( () => {
        panStep()
        setInterval(panStep,5000)
    })


})